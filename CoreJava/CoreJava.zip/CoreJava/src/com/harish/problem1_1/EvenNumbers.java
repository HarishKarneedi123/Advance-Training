package com.harish.problem1_1;

import java.util.Scanner;

public class EvenNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner X = new Scanner(System.in);

        

	       System.out.println("Enter value n : ");

	      int  n = X.nextInt();

	         

	       for(int i=0; i<=n; i++)

	       {

	           if(i%2==0)

	               System.out.println(i+" ");

	       }    

	       System.out.println();

	         

	   }


	}


