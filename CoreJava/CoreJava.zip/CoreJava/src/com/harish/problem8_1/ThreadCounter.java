package com.harish.problem8_1;

class ThreadCounter

{

	public static void main(String args[])

	{

		Counter counter = new Counter(25);

		counter.run();

	}

}