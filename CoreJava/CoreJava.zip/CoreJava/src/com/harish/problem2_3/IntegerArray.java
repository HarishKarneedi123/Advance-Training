package com.harish.problem2_3;

import java.util.Arrays;

public class IntegerArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = new int[] { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0 };
		 int tot=0;
	        int sum=0;
	        int[] arr1;
			for(int i =0;i<15;i++){
	            sum=sum+arr[i];
	        }
	        arr[15]=sum;
	        for(int i=0;i<arr.length;i++){
	            tot=tot+arr[i];
	        }
	        double avg=tot/arr.length;
	        arr[16]=(int)avg;
	        int s=arr[0];
	        for(int i=1;i<=15;i++){
	            if(s>arr[i]){
	                s=arr[i];
	            }
	        }
	        arr[17]=s;
	        
	        for(int i=0;i<arr.length;i++){
	            System.out.println(arr[i]);
	        }
	    }
	}